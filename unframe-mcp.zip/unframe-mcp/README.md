# unframe-mcp

MCP server that fetches and preprocesses Framer components for Claude Code to translate to standalone React TypeScript.

**No Anthropic API key needed.** Claude Code does the translation itself — the MCP just handles the HTTP fetching and import normalization.

---

## How it works

1. You tell Claude Code: *"fetch this Framer component and convert it to React"*
2. Claude Code calls the `fetch_framer_component` MCP tool with the URL
3. The MCP server fetches the component source from Framer's CDN and normalizes URL-based imports
4. Claude Code receives the source + detailed translation instructions
5. Claude Code translates and writes the `.tsx` file to your repo

---

## Setup

### 1. Clone & install

```bash
# Put it somewhere permanent — you'll reference this path in the config
git clone https://github.com/yourusername/unframe-mcp ~/scripts/unframe-mcp
cd ~/scripts/unframe-mcp
npm install
```

### 2. Register with Claude Code

**Option A — Global (available in all projects):**

```bash
claude mcp add unframe node /absolute/path/to/unframe-mcp/server.mjs
```

Replace `/absolute/path/to/unframe-mcp` with where you cloned it, e.g. `~/scripts/unframe-mcp`.

**Option B — Manual edit** of `~/.claude.json`:

```json
{
  "mcpServers": {
    "unframe": {
      "command": "node",
      "args": ["/Users/lucas/scripts/unframe-mcp/server.mjs"],
      "type": "stdio"
    }
  }
}
```

**Option C — Per-project** (add `.mcp.json` to any repo root):

```json
{
  "mcpServers": {
    "unframe": {
      "command": "node",
      "args": ["/Users/lucas/scripts/unframe-mcp/server.mjs"]
    }
  }
}
```

### 3. Verify

```bash
claude mcp list
# Should show: unframe
```

---

## Usage with Claude Code

### Getting the component URL

You need the Framer **module URL** — it looks like:
```
https://framer.com/m/DepthGlobe-Abc1.js@someHash
```

How to get it:

| Source | How |
|---|---|
| framer.university | Click **"Copy component"** on any resource page |
| Framer editor | Assets panel → right-click component → **"Copy URL"** |
| Framer marketplace | Click **"Copy Component"** on a component page |

### Prompts that work well

```
Fetch the Framer component at https://framer.com/m/Globe-XXXX.js@hash,
convert it to standalone React TypeScript, and save it to src/components/DepthGlobe.tsx
```

```
Get the Framer component from https://framer.com/m/ShaderButton-XYZ.js@abc
and convert it to React. Save to components/ShaderButton.tsx. Then show me
how to use it in a Next.js page.
```

```
Use the unframe tool to fetch https://framer.com/m/TextReveal-ABC.js@def
and convert it to a React component I can use with framer-motion.
```

---

## MCP Tools

### `fetch_framer_component`

Fetches a Framer component and returns its preprocessed source + translation instructions.

**Input:**
```json
{ "url": "https://framer.com/m/ComponentName-XXXX.js@hash" }
```

**Returns:** The preprocessed component source with a full translation guide so Claude Code knows exactly what to strip, remap, and generate.

Also accepts framer.university and marketplace page URLs (scrapes for the module URL).

---

### `resolve_framer_url`

Resolves any Framer-related URL to its direct `framer.com/m/` module URL — without fetching the full source.

**Input:**
```json
{ "url": "https://framer.university/resources/depth-globe-component-for-framer" }
```

**Returns:** The canonical module URL and detected component name.

---

## What the output looks like

After Claude Code runs the conversion, you get a clean `.tsx` file like:

```tsx
// Converted from Framer by unframe

import React, { useRef, useEffect, useState } from 'react'
import { motion } from 'framer-motion'

interface Props {
  detail?: 'Low' | 'Medium' | 'High'
  scale?: number
  depth?: number
  spin?: boolean
  backgroundColor?: string
  landColor?: string
  waterColor?: string
}

function DepthGlobe({
  detail = 'Medium',
  scale = 1,
  spin = true,
  backgroundColor = '#000000',
}: Props) {
  // ... all original canvas/WebGL code preserved exactly
}

export { DepthGlobe }
export default DepthGlobe
```

Then:

```bash
npm install framer-motion
```

```tsx
import DepthGlobe from './components/DepthGlobe'

export default function Page() {
  return <DepthGlobe detail="High" spin backgroundColor="#000" />
}
```

---

## Troubleshooting

**"No Framer module URL found in page"**
The page doesn't have the module URL in its static HTML (set via JavaScript). Click "Copy component" on the page manually and pass that URL directly.

**"Access denied (403)"**
Premium component. If you've purchased it, open it in Framer and use Assets → "Copy URL" from within your project.

**Component has residual Framer-isms after translation**
Tell Claude Code to fix them: *"The component still imports from 'framer' — remove those and regenerate the Props interface from the addPropertyControls at the bottom."*

**Server not showing up in Claude Code**
Verify the path in your config is absolute, not `~/`. Run `node /absolute/path/server.mjs` directly to confirm it starts without errors.

---

## Running tests

```bash
npm run test:tools
```
