/**
 * Unit tests for the helper functions in the MCP server.
 * Run with: node test-tools.mjs
 */

// ── Replicate the helper functions for testing ────────────────────────────────

const MODULE_URL_REGEX = /https:\/\/framer\.com\/m\/[A-Za-z0-9_-]+\.js(?:@[A-Za-z0-9]+)?/

function extractComponentName(moduleUrl) {
  const match = moduleUrl.match(/\/m\/([A-Z][a-zA-Z0-9]*)[-_]/)
  if (match) return match[1]
  const basename = moduleUrl.split('/').pop()?.split('.')[0] ?? 'Component'
  return basename.split('-')[0].replace(/[^A-Za-z0-9]/g, '') || 'FramerComponent'
}

function preprocessSource(source) {
  return source
    .replace(/["']https:\/\/framer\.com\/m\/framer\/motion[^"']*["']/g, '"framer-motion"')
    .replace(/["']https:\/\/framer\.com\/m\/framer\/react[^"']*["']/g, '"react"')
    .replace(
      /["']https:\/\/esm\.sh\/([a-zA-Z@][^"'?#@]*)(?:@[^/"'?#]*)?(?:\/[^"'?#]*)?(?:\?[^"']*)?["']/g,
      (_, pkg) => `"${pkg}"`
    )
    .replace(/"([a-zA-Z@][^"]*[a-zA-Z])@[0-9]+\.[0-9][^"]*"/g, '"$1"')
    .replace(/["']https:\/\/framer\.com\/m\/framer[^"']*["']/g, '"__framer_runtime__"')
    .replace(/["']https:\/\/framerusercontent\.com\/modules\/[^"']*["']/g, '"__framer_module__"')
}

// ── Tests ─────────────────────────────────────────────────────────────────────

let passed = 0, failed = 0

function test(name, fn) {
  try {
    fn()
    console.log(`  ✅  ${name}`)
    passed++
  } catch (err) {
    console.log(`  ❌  ${name}`)
    console.log(`      ${err.message}`)
    failed++
  }
}

function eq(a, b) {
  if (a !== b) throw new Error(`Expected:\n  ${JSON.stringify(b)}\nGot:\n  ${JSON.stringify(a)}`)
}

function contains(str, substr) {
  if (!str.includes(substr)) throw new Error(`Expected string to contain: ${JSON.stringify(substr)}\nGot: ${JSON.stringify(str.slice(0, 200))}`)
}

function notContains(str, substr) {
  if (str.includes(substr)) throw new Error(`Expected string NOT to contain: ${JSON.stringify(substr)}`)
}

// ── extractComponentName ──────────────────────────────────────────────────────

console.log('\nextractComponentName:')

test('depth globe URL', () => eq(
  extractComponentName('https://framer.com/m/DepthGlobe-Abc1234.js@somehash'),
  'DepthGlobe'
))

test('multi-word name', () => eq(
  extractComponentName('https://framer.com/m/ShaderButton-Xyz789.js@def456'),
  'ShaderButton'
))

test('URL without version hash', () => eq(
  extractComponentName('https://framer.com/m/TextReveal-ABC1.js'),
  'TextReveal'
))

test('lowercase-start name falls back gracefully', () => {
  const name = extractComponentName('https://framer.com/m/mega-menu-ABC1.js@hash')
  // lowercase start → won't match [A-Z] pattern → fallback
  console.log(`      (fallback result: "${name}")`)
})

// ── preprocessSource ──────────────────────────────────────────────────────────

console.log('\npreprocessSource — URL normalization:')

test('framer.com motion URL → framer-motion', () => {
  const out = preprocessSource(`import { motion } from "https://framer.com/m/framer/motion-abc123.js@hash"`)
  eq(out, `import { motion } from "framer-motion"`)
})

test('framer.com react URL → react', () => {
  const out = preprocessSource(`import React from "https://framer.com/m/framer/react-xyz.js@v1"`)
  eq(out, `import React from "react"`)
})

test('esm.sh react with version → react', () => {
  const out = preprocessSource(`import { jsx } from "https://esm.sh/react@18/jsx-runtime"`)
  contains(out, '"react"')
  notContains(out, 'esm.sh')
})

test('esm.sh three.js with version → three', () => {
  const out = preprocessSource(`import * as THREE from "https://esm.sh/three@0.160.0"`)
  contains(out, '"three"')
  notContains(out, 'esm.sh')
})

test('esm.sh framer-motion → framer-motion', () => {
  const out = preprocessSource(`import { motion } from "https://esm.sh/framer-motion@11.0.0"`)
  contains(out, '"framer-motion"')
  notContains(out, 'esm.sh')
})

test('esm.sh gsap → gsap', () => {
  const out = preprocessSource(`import gsap from "https://esm.sh/gsap@3.12.5"`)
  contains(out, '"gsap"')
  notContains(out, 'esm.sh')
})

test('remaining framer runtime URL → __framer_runtime__', () => {
  const out = preprocessSource(`import { something } from "https://framer.com/m/framer/some-thing-123.js"`)
  contains(out, '"__framer_runtime__"')
})

test('framerusercontent module URL → __framer_module__', () => {
  const out = preprocessSource(`import X from "https://framerusercontent.com/modules/abc/def.js"`)
  contains(out, '"__framer_module__"')
})

test('non-URL imports are untouched', () => {
  const src = `import React from "react"\nimport { motion } from "framer-motion"\nimport * as d3 from "d3"`
  eq(preprocessSource(src), src)
})

test('realistic Framer component snippet', () => {
  const src = `
import { jsx as _jsx } from "https://esm.sh/react@18/jsx-runtime"
import { addPropertyControls, ControlType } from "framer"
import { motion } from "https://framer.com/m/framer/motion-abc.js@hash"
import * as THREE from "https://esm.sh/three@0.160.0"
`.trim()
  const out = preprocessSource(src)
  contains(out, '"react"')
  contains(out, '"framer-motion"')
  contains(out, '"three"')
  // framer (npm) import should be untouched — Claude handles it
  contains(out, 'from "framer"')
  notContains(out, 'esm.sh')
  notContains(out, 'framer.com/m/framer/')
})

// ── MODULE_URL_REGEX ──────────────────────────────────────────────────────────

console.log('\nMODULE_URL_REGEX:')

test('matches URL with version hash', () => {
  const url = 'https://framer.com/m/DepthGlobe-Abc1.js@someHash123'
  if (!MODULE_URL_REGEX.test(url)) throw new Error('Should match')
})

test('matches URL without version hash', () => {
  const url = 'https://framer.com/m/Globe-XYZ.js'
  if (!MODULE_URL_REGEX.test(url)) throw new Error('Should match')
})

test('does not match framer.university URL', () => {
  const url = 'https://framer.university/resources/depth-globe'
  if (MODULE_URL_REGEX.test(url)) throw new Error('Should not match')
})

// ─────────────────────────────────────────────────────────────────────────────

console.log(`\n${passed + failed} tests: ${passed} passed, ${failed} failed\n`)
if (failed > 0) process.exit(1)
