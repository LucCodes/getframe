#!/usr/bin/env node
/**
 * unframe MCP server
 *
 * Slash command:  /unframe <url>
 * Also exposes tools for programmatic use by Claude.
 *
 * Setup: see README.md
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import {
  CallToolRequestSchema,
  ErrorCode,
  GetPromptRequestSchema,
  ListPromptsRequestSchema,
  ListToolsRequestSchema,
  McpError,
} from '@modelcontextprotocol/sdk/types.js'

// ─── URL PATTERNS ─────────────────────────────────────────────────────────────

const MODULE_URL_REGEX = /https:\/\/framer\.com\/m\/[A-Za-z0-9_-]+\.js(?:@[A-Za-z0-9]+)?/

// ─── CORE HELPERS ─────────────────────────────────────────────────────────────

async function resolveModuleUrl(inputUrl) {
  if (MODULE_URL_REGEX.test(inputUrl)) return inputUrl

  const res = await fetch(inputUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      'Accept': 'text/html,application/xhtml+xml,*/*;q=0.9',
    },
    signal: AbortSignal.timeout(10_000),
  })

  if (!res.ok) throw new Error(`Could not fetch page: HTTP ${res.status}`)

  const html = await res.text()
  const match = html.match(MODULE_URL_REGEX)?.[0]
  if (match) return match

  throw new Error(
    `No Framer module URL found in: ${inputUrl}\n\n` +
    `You need the direct module URL. How to get it:\n` +
    `  • framer.university  — click "Copy component" on any resource page\n` +
    `  • Framer editor      — Assets panel → right-click component → "Copy URL"\n` +
    `  • Framer marketplace — click "Copy Component" on a component page\n\n` +
    `The URL looks like: https://framer.com/m/ComponentName-XXXX.js@abc123`
  )
}

function extractComponentName(moduleUrl) {
  const match = moduleUrl.match(/\/m\/([A-Z][a-zA-Z0-9]*)[-_]/)
  if (match) return match[1]
  const basename = moduleUrl.split('/').pop()?.split('.')[0] ?? 'Component'
  return basename.split('-')[0].replace(/[^A-Za-z0-9]/g, '') || 'FramerComponent'
}

function preprocessSource(source) {
  return source
    .replace(/["']https:\/\/framer\.com\/m\/framer\/motion[^"']*["']/g, '"framer-motion"')
    .replace(/["']https:\/\/framer\.com\/m\/framer\/react[^"']*["']/g, '"react"')
    .replace(
      /["']https:\/\/esm\.sh\/([a-zA-Z@][^"'?#@]*)(?:@[^/"'?#]*)?(?:\/[^"'?#]*)?(?:\?[^"']*)?["']/g,
      (_, pkg) => `"${pkg}"`
    )
    .replace(/"([a-zA-Z@][^"]*[a-zA-Z])@[0-9]+\.[0-9][^"]*"/g, '"$1"')
    .replace(/["']https:\/\/framer\.com\/m\/framer[^"']*["']/g, '"__framer_runtime__"')
    .replace(/["']https:\/\/framerusercontent\.com\/modules\/[^"']*["']/g, '"__framer_module__"')
}

async function fetchAndPreprocess(url) {
  const moduleUrl = await resolveModuleUrl(url)
  const componentName = extractComponentName(moduleUrl)

  const res = await fetch(moduleUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; unframe-mcp/1.0)',
      'Accept': 'application/javascript, text/javascript, */*',
    },
    signal: AbortSignal.timeout(15_000),
  })

  if (!res.ok) {
    const hint =
      res.status === 404 ? 'Component not found — URL may be wrong or deleted.' :
      res.status === 403 ? 'Access denied — this component may require a Framer account.' :
      `HTTP ${res.status} ${res.statusText}`
    throw new Error(hint)
  }

  const rawSource = await res.text()
  if (rawSource.length < 100) throw new Error(`Response too small — not a valid component`)

  return {
    componentName,
    moduleUrl,
    processedSource: preprocessSource(rawSource),
    sizeKB: (Buffer.byteLength(rawSource) / 1024).toFixed(1),
  }
}

// ─── TRANSLATION GUIDE ────────────────────────────────────────────────────────

function translationGuide(componentName) {
  return `
## How to convert to standalone React TypeScript

### REMOVE (Framer sidebar API — useless outside Framer):
- All \`import\` statements importing from \`"framer"\`: addPropertyControls, ControlType, Frame, Stack, Scroll, Page, RenderTarget, useVariantState, useCycleVariant, useIsomorphicLayoutEffect, withCSS, etc.
- The entire \`addPropertyControls(${componentName}, { ... })\` call at the bottom
- Imports from \`"__framer_runtime__"\` or \`"__framer_module__"\`

### REMAP (identical API — only the import path changes):
- \`import { motion, AnimatePresence, ... } from "framer"\` → \`from "framer-motion"\`

### GENERATE (from addPropertyControls metadata):
Create \`interface Props\` after imports. ControlType → TypeScript:
- String → \`string\` | Number → \`number\` | Boolean → \`boolean\`
- Color / Image → \`string\` | Enum → union e.g. \`"Low" | "Medium" | "High"\`
- Array → \`T[]\` | EventHandler → \`() => void\` | ComponentInstance → \`React.ReactNode\`

All props optional (\`?\`), with defaults matching \`defaultValue\` in the controls.

### REPLACE:
- \`<Frame\` → \`<motion.div\` (animated) or \`<div\` (static)
- \`<Stack\` → \`<div\` with flex/grid styles

### PRESERVE — DO NOT MODIFY:
- ALL canvas / WebGL / Three.js / shader / GPU rendering code — exact characters
- All \`useState\`, \`useReducer\`, \`useRef\`, \`useCallback\`, \`useMemo\`
- All \`useEffect\`, animation loops, timers, math, geometry
- All non-Framer third-party imports and their usage

### OUTPUT:
\`\`\`tsx
// Converted from Framer by unframe
import React, { ... } from 'react'
import { motion, ... } from 'framer-motion'  // only if used

interface Props { /* generated from addPropertyControls */ }

function ${componentName}({ ... }: Props) { /* original logic intact */ }

export { ${componentName} }
export default ${componentName}
\`\`\`
Output ONLY the .tsx code. No markdown fences. No explanation.
`.trim()
}

// ─── PROMPT CONTENT ───────────────────────────────────────────────────────────

function buildPromptText({ componentName, moduleUrl, processedSource, sizeKB }) {
  return [
    `## Framer Component: ${componentName}`,
    `**Module URL:** ${moduleUrl}`,
    `**Source size:** ${sizeKB} KB`,
    `**Output filename:** ${componentName}.tsx`,
    '',
    '## Preprocessed source (URL imports already normalized):',
    '',
    processedSource,
    '',
    '---',
    '',
    translationGuide(componentName),
    '',
    `---`,
    '',
    `Convert the source above and write it to **${componentName}.tsx** in the most appropriate`,
    `components directory in this project (e.g. \`src/components/\`, \`components/\`, or project root).`,
    `After writing the file, confirm the output path and remind me to run \`npm install framer-motion\` if motion is used.`,
  ].join('\n')
}

// ─── SERVER ───────────────────────────────────────────────────────────────────

const server = new Server(
  { name: 'unframe', version: '2.0.0' },
  { capabilities: { tools: {}, prompts: {} } }  // declare both capabilities
)

// ─── PROMPTS ──────────────────────────────────────────────────────────────────

server.setRequestHandler(ListPromptsRequestSchema, async () => ({
  prompts: [
    {
      name: 'unframe',
      description: 'Fetch a Framer component and convert it to standalone React TypeScript. Usage: /unframe <url>',
      arguments: [
        {
          name: 'url',
          description: 'Framer component URL — direct framer.com/m/... module URL, or a framer.university / Framer marketplace page URL',
          required: true,
        },
      ],
    },
  ],
}))

server.setRequestHandler(GetPromptRequestSchema, async (request) => {
  const { name, arguments: args } = request.params

  if (name !== 'unframe') {
    throw new McpError(ErrorCode.MethodNotFound, `Unknown prompt: ${name}`)
  }

  const url = args?.url
  if (!url || typeof url !== 'string') {
    throw new McpError(ErrorCode.InvalidParams, 'url argument is required. Usage: /unframe <url>')
  }

  // Fetch and preprocess inline — so the source lands right in the prompt context
  const data = await fetchAndPreprocess(url)

  return {
    messages: [
      {
        role: 'user',
        content: {
          type: 'text',
          text: buildPromptText(data),
        },
      },
    ],
  }
})

// ─── TOOLS (programmatic use) ─────────────────────────────────────────────────

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: 'fetch_framer_component',
      description:
        'Fetches a Framer component from a URL and returns its preprocessed source + translation instructions. ' +
        'Prefer the /unframe slash command for interactive use. Use this tool when you need to fetch a component ' +
        'programmatically within a larger task.',
      inputSchema: {
        type: 'object',
        properties: {
          url: {
            type: 'string',
            description: 'Framer component URL (framer.com/m/... or a framer.university/marketplace page URL)',
          },
        },
        required: ['url'],
      },
    },
    {
      name: 'resolve_framer_url',
      description: 'Resolves a framer.university or marketplace page URL to its direct framer.com/m/ module URL.',
      inputSchema: {
        type: 'object',
        properties: {
          url: { type: 'string', description: 'Framer URL to resolve' },
        },
        required: ['url'],
      },
    },
  ],
}))

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params

  try {
    if (name === 'fetch_framer_component') {
      const { url } = args
      if (!url || typeof url !== 'string') {
        throw new McpError(ErrorCode.InvalidParams, 'url is required')
      }
      const data = await fetchAndPreprocess(url)
      return { content: [{ type: 'text', text: buildPromptText(data) }] }
    }

    if (name === 'resolve_framer_url') {
      const { url } = args
      if (!url || typeof url !== 'string') {
        throw new McpError(ErrorCode.InvalidParams, 'url is required')
      }
      const moduleUrl = await resolveModuleUrl(url)
      const componentName = extractComponentName(moduleUrl)
      return {
        content: [{
          type: 'text',
          text: `**Module URL:** ${moduleUrl}\n**Component name:** ${componentName}`,
        }],
      }
    }

    throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`)

  } catch (err) {
    if (err instanceof McpError) throw err
    return {
      content: [{ type: 'text', text: `Error: ${err.message}` }],
      isError: true,
    }
  }
})

// ─── START ────────────────────────────────────────────────────────────────────

const transport = new StdioServerTransport()
await server.connect(transport)
